# Day Widget

A tiny always-on desktop widget for Windows 10 22H2 that shows only the
current day of the week (e.g. `MONDAY`) — no date, no weather. Written in
plain C / Win32 API, so it's extremely light: ~3–8 MB RAM, effectively 0%
CPU (it only wakes up every 30 seconds to check if the day changed).

## 1. Get the Anurati font (not included)

Anurati is a free font but I can't redistribute the font file itself.
Download it yourself from either:

- https://www.dafont.com/anurati.font
- https://www.fontspace.com/anurati-font-f43532

Unzip it and place `Anurati-Regular.otf` (or `.ttf`) in the **same folder**
as `DayWidget.exe`. The app loads it privately at startup — it does **not**
install the font system-wide, so no admin rights are needed.

> If the font file isn't found, the widget still runs fine — it just falls
> back to Segoe UI Bold so you're never stuck with a broken window.

## 2. Run it

Just double-click `DayWidget.exe`. You'll see the current day appear near
the top-right corner of your screen, floating over your desktop with a
transparent background.

- **Drag** it anywhere with left-click.
- **Right-click** for a small menu: toggle "Always on top", toggle
  "Click-through" (lets mouse clicks pass through to whatever's underneath),
  or Exit.
- Position and these two settings are remembered automatically in a
  `daywidget.ini` file created next to the exe.
- It also adds a small tray icon (bottom-right, next to the clock) so you
  can find/right-click it even if it's click-through.

## 3. (Optional) Start automatically with Windows

Press `Win + R`, type `shell:startup`, hit Enter. Copy a **shortcut** to
`DayWidget.exe` into that folder. It'll now launch quietly every time you
log in.

## Notes / customizing

- The source is included (`daywidget.c`) if you want to tweak text size,
  color, position defaults, or the update interval — it's a single ~250
  line file, no dependencies beyond the standard Win32 headers.
- To recompile on Windows: install MinGW-w64 or use MSVC's `cl.exe`, then
  roughly: `gcc -O2 -mwindows -municode -o DayWidget.exe daywidget.c -lgdi32 -luser32 -lshell32`
- Built and cross-compiled for Windows here via mingw-w64, so it's a native
  PE32+ executable — no .NET, no runtime installs needed on your machine.
