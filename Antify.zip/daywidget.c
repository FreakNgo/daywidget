// DayWidget.c
// Ultra-lightweight Windows desktop widget that displays only the current
// day of the week, styled with the "Anurati" font (loaded privately from
// the exe's own folder -- no system install, no admin rights required).
//
// Design goals: minimal RAM (~3-8 MB), near-zero CPU (checks the clock once
// every 30 seconds and only repaints when the day actually changes), no
// external runtime (pure Win32 API, statically-linked CRT).

#include <windows.h>
#include <string.h>
#include <wchar.h>

#define WINDOW_W        260
#define WINDOW_H        70
#define MARGIN_X        24
#define MARGIN_Y        24
#define TIMER_ID        1
#define TIMER_MS        30000          // check clock every 30s -> negligible CPU
#define WM_TRAYICON     (WM_APP + 1)
#define ID_TRAY_TOGGLETOP 1001
#define ID_TRAY_CLICKTHRU 1002
#define ID_TRAY_EXIT      1003

static const wchar_t *kDayNames[7] = {
    L"SUNDAY", L"MONDAY", L"TUESDAY", L"WEDNESDAY",
    L"THURSDAY", L"FRIDAY", L"SATURDAY"
};

static HFONT   g_hFont        = NULL;
static int     g_fontPrivate  = 0;
static wchar_t g_fontDir[MAX_PATH] = L"";
static int     g_lastDay      = -1;
static BOOL    g_alwaysOnTop  = TRUE;
static BOOL    g_clickThrough = FALSE;
static HWND    g_hwnd         = NULL;
static NOTIFYICONDATAW g_nid;

// ---- simple position persistence (ini file next to the exe) ------------
static void GetIniPath(wchar_t *buf, size_t cch) {
    GetModuleFileNameW(NULL, buf, (DWORD)cch);
    wchar_t *slash = wcsrchr(buf, L'\\');
    if (slash) *(slash + 1) = 0;
    wcscat_s(buf, cch, L"daywidget.ini");
}

static void LoadSettings(int *x, int *y) {
    wchar_t ini[MAX_PATH];
    GetIniPath(ini, MAX_PATH);
    RECT wa; SystemParametersInfoW(SPI_GETWORKAREA, 0, &wa, 0);
    int defX = wa.right - WINDOW_W - MARGIN_X;
    int defY = wa.top + MARGIN_Y;
    *x = GetPrivateProfileIntW(L"pos", L"x", defX, ini);
    *y = GetPrivateProfileIntW(L"pos", L"y", defY, ini);
    g_alwaysOnTop  = GetPrivateProfileIntW(L"opt", L"ontop", 1, ini) != 0;
    g_clickThrough = GetPrivateProfileIntW(L"opt", L"clickthrough", 0, ini) != 0;
}

static void SaveSettings(HWND hwnd) {
    wchar_t ini[MAX_PATH];
    GetIniPath(ini, MAX_PATH);
    RECT r; GetWindowRect(hwnd, &r);
    wchar_t buf[32];
    swprintf_s(buf, 32, L"%d", r.left);  WritePrivateProfileStringW(L"pos", L"x", buf, ini);
    swprintf_s(buf, 32, L"%d", r.top);   WritePrivateProfileStringW(L"pos", L"y", buf, ini);
    swprintf_s(buf, 32, L"%d", g_alwaysOnTop  ? 1 : 0); WritePrivateProfileStringW(L"opt", L"ontop", buf, ini);
    swprintf_s(buf, 32, L"%d", g_clickThrough ? 1 : 0); WritePrivateProfileStringW(L"opt", L"clickthrough", buf, ini);
}

// ---- font loading --------------------------------------------------------
static void LoadWidgetFont(void) {
    wchar_t exeDir[MAX_PATH];
    GetModuleFileNameW(NULL, exeDir, MAX_PATH);
    wchar_t *slash = wcsrchr(exeDir, L'\\');
    if (slash) *(slash + 1) = 0;

    const wchar_t *candidates[] = { L"Anurati-Regular.otf", L"Anurati-Regular.ttf",
                                     L"Anurati.otf", L"Anurati.ttf" };
    for (int i = 0; i < 4; i++) {
        wchar_t path[MAX_PATH];
        swprintf_s(path, MAX_PATH, L"%s%s", exeDir, candidates[i]);
        if (GetFileAttributesW(path) != INVALID_FILE_ATTRIBUTES) {
            if (AddFontResourceExW(path, FR_PRIVATE, 0) > 0) {
                g_fontPrivate = 1;
                break;
            }
        }
    }

    const wchar_t *faceName = g_fontPrivate ? L"Anurati" : L"Segoe UI";
    g_hFont = CreateFontW(
        g_fontPrivate ? 30 : 34, 0, 0, 0,
        g_fontPrivate ? FW_NORMAL : FW_BOLD,
        FALSE, FALSE, FALSE,
        DEFAULT_CHARSET, OUT_TT_PRECIS, CLIP_DEFAULT_PRECIS,
        NONANTIALIASED_QUALITY,   // hard edges -> clean with colour-key transparency
        DEFAULT_PITCH | FF_DONTCARE,
        faceName);
}

// ---- drawing --------------------------------------------------------------
static void DrawWidget(HWND hwnd, HDC hdc) {
    RECT rc; GetClientRect(hwnd, &rc);

    HDC memDC = CreateCompatibleDC(hdc);
    HBITMAP bmp = CreateCompatibleBitmap(hdc, rc.right, rc.bottom);
    HBITMAP oldBmp = (HBITMAP)SelectObject(memDC, bmp);

    // colour-key background (pure black == transparent)
    HBRUSH bg = CreateSolidBrush(RGB(0, 0, 0));
    FillRect(memDC, &rc, bg);
    DeleteObject(bg);

    SYSTEMTIME st; GetLocalTime(&st);
    const wchar_t *day = kDayNames[st.wDayOfWeek];

    HFONT oldFont = (HFONT)SelectObject(memDC, g_hFont);
    SetBkMode(memDC, TRANSPARENT);
    SetTextColor(memDC, RGB(235, 235, 235));

    // manual letter tracking for that wide sci-fi look Anurati is designed for
    int trackingPx = g_fontPrivate ? 6 : 3;
    SIZE totalSz = {0, 0};
    int len = (int)wcslen(day);
    for (int i = 0; i < len; i++) {
        SIZE sz; GetTextExtentPoint32W(memDC, &day[i], 1, &sz);
        totalSz.cx += sz.cx + trackingPx;
        totalSz.cy = sz.cy;
    }
    totalSz.cx -= trackingPx;

    int x = (rc.right - totalSz.cx) / 2;
    int y = (rc.bottom - totalSz.cy) / 2;
    for (int i = 0; i < len; i++) {
        TextOutW(memDC, x, y, &day[i], 1);
        SIZE sz; GetTextExtentPoint32W(memDC, &day[i], 1, &sz);
        x += sz.cx + trackingPx;
    }

    SelectObject(memDC, oldFont);
    BitBlt(hdc, 0, 0, rc.right, rc.bottom, memDC, 0, 0, SRCCOPY);

    SelectObject(memDC, oldBmp);
    DeleteObject(bmp);
    DeleteDC(memDC);

    g_lastDay = st.wDayOfWeek;
}

static void ApplyExStyles(HWND hwnd) {
    LONG_PTR ex = GetWindowLongPtrW(hwnd, GWL_EXSTYLE);
    ex |= WS_EX_LAYERED;
    if (g_clickThrough) ex |= WS_EX_TRANSPARENT; else ex &= ~WS_EX_TRANSPARENT;
    SetWindowLongPtrW(hwnd, GWL_EXSTYLE, ex);
    SetWindowPos(hwnd, g_alwaysOnTop ? HWND_TOPMOST : HWND_NOTOPMOST,
                 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE);
}

static void ShowTrayMenu(HWND hwnd) {
    POINT pt; GetCursorPos(&pt);
    HMENU menu = CreatePopupMenu();
    AppendMenuW(menu, MF_STRING | (g_alwaysOnTop ? MF_CHECKED : 0), ID_TRAY_TOGGLETOP, L"Always on top");
    AppendMenuW(menu, MF_STRING | (g_clickThrough ? MF_CHECKED : 0), ID_TRAY_CLICKTHRU, L"Click-through");
    AppendMenuW(menu, MF_SEPARATOR, 0, NULL);
    AppendMenuW(menu, MF_STRING, ID_TRAY_EXIT, L"Exit");
    SetForegroundWindow(hwnd);
    TrackPopupMenu(menu, TPM_RIGHTBUTTON, pt.x, pt.y, 0, hwnd, NULL);
    DestroyMenu(menu);
}

static LRESULT CALLBACK WndProc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    switch (msg) {
    case WM_CREATE:
        SetLayeredWindowAttributes(hwnd, RGB(0, 0, 0), 0, LWA_COLORKEY);
        SetTimer(hwnd, TIMER_ID, TIMER_MS, NULL);
        return 0;

    case WM_TIMER: {
        SYSTEMTIME st; GetLocalTime(&st);
        if ((int)st.wDayOfWeek != g_lastDay) InvalidateRect(hwnd, NULL, FALSE);
        return 0;
    }

    case WM_PAINT: {
        PAINTSTRUCT ps;
        HDC hdc = BeginPaint(hwnd, &ps);
        DrawWidget(hwnd, hdc);
        EndPaint(hwnd, &ps);
        return 0;
    }

    case WM_LBUTTONDOWN:
        ReleaseCapture();
        SendMessageW(hwnd, WM_NCLBUTTONDOWN, HTCAPTION, 0);
        return 0;

    case WM_ENTERSIZEMOVE:
        return 0;
    case WM_EXITSIZEMOVE:
        SaveSettings(hwnd);
        return 0;

    case WM_RBUTTONUP:
    case WM_TRAYICON:
        if (msg == WM_TRAYICON && lp != WM_RBUTTONUP) return 0;
        ShowTrayMenu(hwnd);
        return 0;

    case WM_COMMAND:
        switch (LOWORD(wp)) {
        case ID_TRAY_TOGGLETOP:
            g_alwaysOnTop = !g_alwaysOnTop;
            ApplyExStyles(hwnd);
            SaveSettings(hwnd);
            return 0;
        case ID_TRAY_CLICKTHRU:
            g_clickThrough = !g_clickThrough;
            ApplyExStyles(hwnd);
            SaveSettings(hwnd);
            return 0;
        case ID_TRAY_EXIT:
            DestroyWindow(hwnd);
            return 0;
        }
        return 0;

    case WM_DESTROY:
        SaveSettings(hwnd);
        Shell_NotifyIconW(NIM_DELETE, &g_nid);
        if (g_fontPrivate) RemoveFontResourceExW(L"", FR_PRIVATE, 0); // best-effort
        PostQuitMessage(0);
        return 0;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

int WINAPI wWinMain(HINSTANCE hInst, HINSTANCE hPrev, LPWSTR cmdLine, int nCmdShow) {
    (void)hPrev; (void)cmdLine;

    // single instance
    HANDLE mutex = CreateMutexW(NULL, TRUE, L"DayWidgetSingleInstanceMutex");
    if (GetLastError() == ERROR_ALREADY_EXISTS) return 0;

    LoadWidgetFont();

    WNDCLASSEXW wc = {0};
    wc.cbSize = sizeof(wc);
    wc.lpfnWndProc = WndProc;
    wc.hInstance = hInst;
    wc.hCursor = LoadCursorW(NULL, IDC_ARROW);
    wc.hbrBackground = NULL;
    wc.lpszClassName = L"DayWidgetClass";
    RegisterClassExW(&wc);

    int x, y;
    LoadSettings(&x, &y);

    DWORD exStyle = WS_EX_LAYERED | WS_EX_TOOLWINDOW | WS_EX_NOACTIVATE;
    if (g_alwaysOnTop) exStyle |= WS_EX_TOPMOST;
    if (g_clickThrough) exStyle |= WS_EX_TRANSPARENT;

    g_hwnd = CreateWindowExW(exStyle, L"DayWidgetClass", L"Day Widget",
                              WS_POPUP, x, y, WINDOW_W, WINDOW_H,
                              NULL, NULL, hInst, NULL);

    SetLayeredWindowAttributes(g_hwnd, RGB(0, 0, 0), 0, LWA_COLORKEY);
    ShowWindow(g_hwnd, SW_SHOWNOACTIVATE);
    UpdateWindow(g_hwnd);

    // tray icon so it's easy to find & exit
    ZeroMemory(&g_nid, sizeof(g_nid));
    g_nid.cbSize = sizeof(g_nid);
    g_nid.hWnd = g_hwnd;
    g_nid.uID = 1;
    g_nid.uFlags = NIF_ICON | NIF_MESSAGE | NIF_TIP;
    g_nid.uCallbackMessage = WM_TRAYICON;
    g_nid.hIcon = LoadIconW(NULL, IDI_APPLICATION);
    wcscpy_s(g_nid.szTip, ARRAYSIZE(g_nid.szTip), L"Day Widget (right-click for options)");
    Shell_NotifyIconW(NIM_ADD, &g_nid);

    MSG msg;
    while (GetMessageW(&msg, NULL, 0, 0)) {
        TranslateMessage(&msg);
        DispatchMessageW(&msg);
    }

    CloseHandle(mutex);
    return (int)msg.wParam;
}
